import Image from "next/image"
import Link from "next/link"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Users } from "lucide-react"
import AnimatedStat from "@/components/animated-stat"

export default function WhereWeWorkPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <section className="relative h-[300px]">
          <div className="absolute inset-0">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5_2025-03-12_15-05-16.jpg-5Zw85q0evMUaDvOZ1RiWu0T21jxyk8.jpeg"
              alt="Where We Work"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
          <div className="relative h-full flex items-center">
            <div className="container mx-auto px-4">
              <h1 className="text-4xl font-bold text-white">Where We Work</h1>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold text-blue-700 mb-4">Our Reach Across Ethiopia</h2>
              <p className="text-gray-700">
                HEAL-Ethiopia operates in multiple regions across the country, implementing programs that address the
                specific needs and challenges of diverse communities. Our presence in both urban and rural areas allows
                us to create meaningful impact throughout Ethiopia.
              </p>
            </div>

            <div className="mb-16">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg mb-8">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2_2025-03-12_15-06-25.jpg-TTqX57rTTwAdCtE0fG9iqZYdYwKSp9.jpeg"
                  alt="Map of Ethiopia showing our locations"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                  <p className="text-white text-xl font-bold">Our Presence in Ethiopia</p>
                </div>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-blue-700 mb-4">Regions We Serve</h3>
                <p className="text-gray-700">
                  HEAL-Ethiopia currently operates in Addis Ababa and Diredewa City Administration, Tigray, Afar,
                  Amhara, Oromia, and SNNP Regional States. Our programs are tailored to address the specific needs and
                  challenges of each region.
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-12 mb-16">
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-64">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_3_2025-03-12_15-05-16.jpg-qQxd8G6Lnzf9dW6GwMeiObsaY2009z.jpeg"
                    alt="Our Locations"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 text-green-400 mr-2" />
                      <h3 className="text-xl font-bold text-white">Our Locations</h3>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-gray-700 mb-4">
                    HEAL-Ethiopia operates in six key regions across Ethiopia, including Addis Ababa, Oromia, Amhara,
                    SNNPR, Tigray, and Afar regions. Each location has programs tailored to address local needs and
                    challenges.
                  </p>
                  <Link href="/where-we-work/locations">
                    <Button className="w-full bg-green-600 hover:bg-green-700 text-white">Explore Our Locations</Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-64">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_4_2025-03-12_15-05-16.jpg-L2JSun8f3updVeaa8RABrxsZImeb4K.jpeg"
                    alt="Communities We Serve"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                    <div className="flex items-center">
                      <Users className="h-5 w-5 text-green-400 mr-2" />
                      <h3 className="text-xl font-bold text-white">How We Work</h3>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-gray-700 mb-4">
                    For almost two decades, HEAL has diligently pursued its mission by closely collaborating with
                    marginalized communities, governmental bodies, and partner agencies. Our approach emphasizes
                    teamwork, personal accountability, integrity, and professionalism.
                  </p>
                  <Link href="/where-we-work/communities">
                    <Button className="w-full bg-blue-700 hover:bg-blue-800 text-white">
                      Learn About Our Approach
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>

            <div className="max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold text-blue-700 mb-6 text-center">Our Impact Across Ethiopia</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center mb-12">
                <AnimatedStat value="6" label="Regions" color="text-green-700" />
                <AnimatedStat value="30+" label="Communities" color="text-yellow-500" />
                <AnimatedStat value="1.3M+" label="Lives Impacted" color="text-red-600" />
                <AnimatedStat value="100+" label="Projects Completed" color="text-blue-700" />
              </div>

              <div className="bg-blue-50 p-8 rounded-lg text-center">
                <h4 className="text-xl font-semibold text-blue-700 mb-4">Breaking the Cycle of Poverty</h4>
                <p className="text-gray-700 mb-6">
                  HEAL firmly believes in and actively works on collaborative efforts among governments, NGOs,
                  universities, research institutions, communities, and the private sector to combat poverty's root
                  causes.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <Link href="/impacts">
                    <Button className="bg-green-600 hover:bg-green-700 text-white">Explore Our Impact</Button>
                  </Link>
                  <Link href="/donate">
                    <Button className="bg-red-600 hover:bg-red-700 text-white">Support Our Work</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

