import Image from "next/image"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Users } from "lucide-react"

const communities = [
  {
    name: "Urban Youth",
    description:
      "We work with young people in urban areas, providing education, vocational training, and life skills to help them reach their full potential and contribute to their communities.",
    challenges: ["Limited access to quality education", "Unemployment", "Health risks including HIV/AIDS"],
    approaches: ["Youth-led initiatives", "Peer education", "Skills development programs"],
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    name: "Rural Families",
    description:
      "Our programs support rural families by improving access to essential services, promoting sustainable agriculture, and building community resilience.",
    challenges: ["Food insecurity", "Limited healthcare access", "Environmental degradation"],
    approaches: ["Sustainable farming techniques", "Community health workers", "Water and sanitation projects"],
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    name: "Women and Girls",
    description:
      "We focus on empowering women and girls through education, economic opportunities, and health services, recognizing their crucial role in community development.",
    challenges: ["Gender inequality", "Limited economic opportunities", "Maternal health risks"],
    approaches: ["Girls' education programs", "Women's savings groups", "Maternal health services"],
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    name: "Children",
    description:
      "Our child-focused programs ensure that children have access to education, healthcare, and protection, giving them the foundation they need for a bright future.",
    challenges: ["School dropout", "Malnutrition", "Child protection issues"],
    approaches: ["Early childhood development", "School feeding programs", "Child protection networks"],
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    name: "Pastoral Communities",
    description:
      "We work with pastoral communities to address their unique challenges, focusing on water access, livestock health, and alternative livelihoods.",
    challenges: ["Drought vulnerability", "Limited access to services", "Land use conflicts"],
    approaches: ["Water harvesting", "Mobile health services", "Conflict resolution"],
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    name: "People with Disabilities",
    description:
      "Our inclusive programs ensure that people with disabilities have equal access to services and opportunities, promoting their full participation in community life.",
    challenges: ["Discrimination", "Physical barriers", "Limited specialized services"],
    approaches: ["Inclusive education", "Accessibility improvements", "Disability awareness"],
    image: "/placeholder.svg?height=300&width=500",
  },
]

export default function CommunitiesPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <section className="relative h-[300px]">
          <div className="absolute inset-0">
            <Image
              src="/placeholder.svg?height=300&width=1200"
              alt="Communities We Serve"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
          <div className="relative h-full flex items-center">
            <div className="container mx-auto px-4">
              <h1 className="text-4xl font-bold text-white">Communities We Serve</h1>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold text-blue-700 mb-4">Our Community Focus</h2>
              <p className="text-gray-700">
                At Hiwot Ethiopia, we work with diverse communities across the country, tailoring our approaches to
                address their specific needs and challenges. We believe in community-led development that empowers
                people to create positive change in their own lives.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {communities.map((community, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative h-64">
                    <Image
                      src={community.image || "/placeholder.svg"}
                      alt={community.name}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                      <div className="flex items-center">
                        <Users className="h-5 w-5 text-green-400 mr-2" />
                        <h3 className="text-xl font-bold text-white">{community.name}</h3>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-gray-700 mb-4">{community.description}</p>
                    <div className="mb-4">
                      <h4 className="font-semibold text-red-600 mb-2">Key Challenges:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        {community.challenges.map((challenge, i) => (
                          <li key={i} className="text-gray-700">
                            {challenge}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-green-700 mb-2">Our Approaches:</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        {community.approaches.map((approach, i) => (
                          <li key={i} className="text-gray-700">
                            {approach}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-blue-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-blue-700 mb-6 text-center">Our Community-Centered Approach</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold text-green-700 mb-3">Listen</h3>
                  <p className="text-gray-700">
                    We begin by listening to community members, understanding their needs, challenges, and aspirations
                    through participatory assessments.
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold text-yellow-600 mb-3">Collaborate</h3>
                  <p className="text-gray-700">
                    We work together with communities to design and implement programs that address their priorities and
                    build on existing strengths.
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="text-xl font-semibold text-red-600 mb-3">Empower</h3>
                  <p className="text-gray-700">
                    We focus on building capacity and transferring skills, ensuring that communities can sustain and
                    expand positive changes over time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

