"use client"

import { useEffect } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

const images = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_1_2025-03-12_15-05-16.jpg-7edrsPwrFOU0ZdnJEGZCkjAbw2IlNx.jpeg",
    title: "Youth Computer Training",
    description:
      "Students participating in our computer literacy program, developing essential digital skills for the future.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_4_2025-03-12_15-06-25.jpg-7T1NZrk7supk9JOCfHJ7PtaCyuZ0g0.jpeg",
    title: "Women's Economic Empowerment",
    description: "Women entrepreneurs running their small business, part of our economic empowerment initiative.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2_2025-03-12_15-05-16.jpg-mMXrVxaVVNbQgYy54Bew4Y9vLaZVCX.jpeg",
    title: "Community Training Session",
    description: "Participants engaged in a capacity building workshop, developing skills for community development.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5_2025-03-12_15-06-25.jpg-VJTcLRgPSZFGChVGEt5efohdpriphp.jpeg",
    title: "Leadership Engagement",
    description: "Community leaders and stakeholders participating in strategic planning discussions.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_4_2025-03-12_15-05-16.jpg-L2JSun8f3updVeaa8RABrxsZImeb4K.jpeg",
    title: "Community Health Outreach",
    description: "Health education and support services being provided to indigenous communities.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2_2025-03-12_15-06-25.jpg-TTqX57rTTwAdCtE0fG9iqZYdYwKSp9.jpeg",
    title: "Livestock Program",
    description: "Community members benefiting from our livestock support program, improving livelihoods.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_3_2025-03-12_15-06-25.jpg-KOrp1zegMicGoxJqcKhEy2AcUkfJTE.jpeg",
    title: "Youth Support",
    description: "Distribution of essential supplies to youth participants in our programs.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5_2025-03-12_15-05-16.jpg-5Zw85q0evMUaDvOZ1RiWu0T21jxyk8.jpeg",
    title: "Community Engagement",
    description: "Participatory discussion with local communities to understand needs and plan interventions.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_1_2025-03-12_15-06-25.jpg-8u9cVs1JwypAYn603l0JgG8lVUq2Ly.jpeg",
    title: "Education Support",
    description: "Students showing their new educational materials provided through our support program.",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_3_2025-03-12_15-05-16.jpg-qQxd8G6Lnzf9dW6GwMeiObsaY2009z.jpeg",
    title: "Agricultural Development",
    description: "Community members working together on sustainable farming practices.",
  },
]

export default function GalleryPage() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gray-50">
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.h1
              className="text-4xl font-bold text-blue-700 text-center mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Our Impact in Pictures
            </motion.h1>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {images.map((image, index) => (
                <motion.div
                  key={index}
                  className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="relative h-64">
                    <Image src={image.src || "/placeholder.svg"} alt={image.title} fill className="object-cover" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-green-700 mb-2">{image.title}</h3>
                    <p className="text-gray-700">{image.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

