"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const slideImages = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_1_2025-03-12_15-05-16.jpg-7edrsPwrFOU0ZdnJEGZCkjAbw2IlNx.jpeg", // Computer training
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2_2025-03-12_15-05-16.jpg-mMXrVxaVVNbQgYy54Bew4Y9vLaZVCX.jpeg", // Community training
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_1_2025-03-12_15-06-25.jpg-8u9cVs1JwypAYn603l0JgG8lVUq2Ly.jpeg", // Students with books
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_4_2025-03-12_15-05-16.jpg-L2JSun8f3updVeaa8RABrxsZImeb4K.jpeg", // Community health
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_3_2025-03-12_15-05-16.jpg-qQxd8G6Lnzf9dW6GwMeiObsaY2009z.jpeg", // Agricultural work
]

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  // Auto-advance slides
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slideImages.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slideImages.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slideImages.length) % slideImages.length)
  }

  return (
    <section className="relative h-[500px] md:h-[600px]">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          <Image
            src={slideImages[currentSlide] || "/placeholder.svg"}
            alt="Empowering communities in Ethiopia"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black/50"></div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full z-10"
        aria-label="Previous slide"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full z-10"
        aria-label="Next slide"
      >
        <ChevronRight size={24} />
      </button>

      {/* Slide indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
        {slideImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full ${currentSlide === index ? "bg-white" : "bg-white/50"}`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      <div className="relative h-full flex items-center">
        <div className="container mx-auto px-4">
          <motion.div
            className="max-w-2xl text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Helping Ethiopia Achieve Longevity</h1>
            <p className="text-lg md:text-xl mb-8">
              We work to break the cycle of poverty and create sustainable change through education, healthcare, and
              community empowerment across Ethiopia.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/about">
                <Button className="bg-green-600 hover:bg-green-700 text-white">Learn More</Button>
              </Link>
              <Link href="/donate">
                <Button className="bg-red-600 hover:bg-red-700 text-white">Support Our Cause</Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

