import Image from "next/image"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CalendarDays, Clock, MapPin } from "lucide-react"

const upcomingEvents = [
  {
    title: "Annual Charity Gala",
    date: "April 15, 2023",
    time: "6:00 PM - 10:00 PM",
    location: "Sheraton Addis, Addis Ababa",
    description:
      "Join us for our annual charity gala to celebrate our achievements and raise funds for our programs. The evening will include dinner, entertainment, and inspiring stories from our beneficiaries.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Youth Leadership Workshop",
    date: "May 5-7, 2023",
    time: "9:00 AM - 4:00 PM",
    location: "Hiwot Ethiopia Training Center, Addis Ababa",
    description:
      "A three-day workshop for young leaders aged 18-25 to develop leadership skills, project management abilities, and community mobilization strategies.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Community Health Fair",
    date: "May 20, 2023",
    time: "10:00 AM - 3:00 PM",
    location: "Kebele Community Center, Oromia Region",
    description:
      "A health fair offering free health screenings, consultations, and health education for community members. Services will include blood pressure checks, HIV testing, and nutrition counseling.",
    image: "/placeholder.svg?height=300&width=500",
  },
]

const pastEvents = [
  {
    title: "World Water Day Celebration",
    date: "March 22, 2023",
    location: "Multiple Locations",
    description:
      "We celebrated World Water Day with events in communities where we've implemented water projects, highlighting the importance of clean water and proper sanitation.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Donor Appreciation Event",
    date: "February 28, 2023",
    location: "Hiwot Ethiopia Headquarters, Addis Ababa",
    description:
      "An event to thank our donors and partners for their support and share updates on our programs and impact.",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    title: "Teacher Training Workshop",
    date: "January 15-17, 2023",
    location: "Amhara Region",
    description:
      "A workshop for primary school teachers on child-centered teaching methods, classroom management, and creating inclusive learning environments.",
    image: "/placeholder.svg?height=300&width=500",
  },
]

export default function EventsPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <section className="relative h-[300px]">
          <div className="absolute inset-0">
            <Image src="/placeholder.svg?height=300&width=1200" alt="Events" fill className="object-cover" />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
          <div className="relative h-full flex items-center">
            <div className="container mx-auto px-4">
              <h1 className="text-4xl font-bold text-white">Events</h1>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto mb-12">
              <h2 className="text-3xl font-bold text-blue-700 mb-6 text-center">Upcoming Events</h2>
              <p className="text-gray-700 text-center mb-8">
                Join us at our upcoming events to learn more about our work, connect with our team, and support our
                cause. We host a variety of events throughout the year, from fundraisers to community activities.
              </p>

              <div className="space-y-8">
                {upcomingEvents.map((event, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-1/3 relative h-64 md:h-auto">
                        <Image
                          src={event.image || "/placeholder.svg"}
                          alt={event.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <CardContent className="p-6 md:w-2/3">
                        <h3 className="text-xl font-bold text-blue-700 mb-2">{event.title}</h3>
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center text-gray-700">
                            <CalendarDays className="h-4 w-4 text-green-600 mr-2" />
                            <span>{event.date}</span>
                          </div>
                          <div className="flex items-center text-gray-700">
                            <Clock className="h-4 w-4 text-green-600 mr-2" />
                            <span>{event.time}</span>
                          </div>
                          <div className="flex items-center text-gray-700">
                            <MapPin className="h-4 w-4 text-green-600 mr-2" />
                            <span>{event.location}</span>
                          </div>
                        </div>
                        <p className="text-gray-700 mb-4">{event.description}</p>
                        <div className="flex space-x-3">
                          <Button className="bg-green-600 hover:bg-green-700 text-white">Register</Button>
                          <Button variant="outline" className="border-blue-600 text-blue-700 hover:bg-blue-50">
                            More Details
                          </Button>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-blue-700 mb-6 text-center">Past Events</h2>
              <div className="grid md:grid-cols-3 gap-8">
                {pastEvents.map((event, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-48">
                      <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-bold text-blue-700 mb-2">{event.title}</h3>
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center text-gray-700">
                          <CalendarDays className="h-4 w-4 text-green-600 mr-2" />
                          <span>{event.date}</span>
                        </div>
                        <div className="flex items-center text-gray-700">
                          <MapPin className="h-4 w-4 text-green-600 mr-2" />
                          <span>{event.location}</span>
                        </div>
                      </div>
                      <p className="text-gray-700 mb-4 text-sm">{event.description}</p>
                      <Button variant="outline" className="w-full border-blue-600 text-blue-700 hover:bg-blue-50">
                        View Gallery
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-blue-50">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h3 className="text-2xl font-bold text-blue-700 mb-4">Host Your Own Event</h3>
              <p className="text-gray-700 mb-6">
                Interested in hosting an event to support Hiwot Ethiopia? Whether it's a fundraiser, awareness campaign,
                or community activity, we'd love to help you make it a success.
              </p>
              <Button className="bg-green-600 hover:bg-green-700 text-white">Contact Us to Get Started</Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

