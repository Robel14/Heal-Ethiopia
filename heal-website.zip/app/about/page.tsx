import Image from "next/image"
import Link from "next/link"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <section className="relative h-[300px]">
          <div className="absolute inset-0">
            <Image
              src="/placeholder.svg?height=300&width=1200"
              alt="About HEAL-Ethiopia"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/50"></div>
          </div>
          <div className="relative h-full flex items-center">
            <div className="container mx-auto px-4">
              <h1 className="text-4xl font-bold text-white">About Us</h1>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-blue-700 mb-6">Our Story</h2>
                <p className="text-gray-700 mb-4">
                  Helping Ethiopia Achieve Longevity (HEAL), formerly known as Nutrition plus Holistic Home Care
                  (NPHHC), was established in September 2003 by Mentuab Araya, a US citizen born in Ethiopia with
                  extensive experience in humanitarian causes.
                </p>
                <p className="text-gray-700 mb-4">
                  Mentuab's journey began after returning to Ethiopia following two decades in the US, where she sought
                  to assist a country grappling with civil war and famine. Her efforts brought foreign investment,
                  notably the BGI group, which now owns breweries and a winery, contributing to the nation's economic
                  revival.
                </p>
                <p className="text-gray-700">
                  Since its establishment, HEAL has positively impacted over 1.3 million lives, focusing on HIV/AIDS,
                  Climate, Women and Youth Empowerment, Hospice Care, and Maternal Neonatal Health, embodying our
                  unwavering commitment to humanitarian causes.
                </p>
              </div>
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Mentuab Araya, Founder of HEAL"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-green-700 mb-4">How We Work</h2>
              <p className="text-gray-700 max-w-3xl mx-auto">
                Helping Ethiopia Achieve Longevity operates under a board-led structure with Executive Director Mr.
                Dereje Deme overseeing day-to-day activities, including program implementation, finances, and
                administration.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-blue-700 mb-4">Our Approach</h3>
                <p className="text-gray-700">
                  For almost two decades, HEAL has diligently pursued its mission by closely collaborating with
                  marginalized communities, governmental bodies, and partner agencies. Our wide-ranging initiatives
                  encompass sustainable development programs, health services, inclusive education, livelihood
                  enhancement, empowerment for women and youth, natural resource management, human rights advocacy,
                  peace and security initiatives, and community awareness efforts.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-red-600 mb-4">Our Commitment</h3>
                <p className="text-gray-700">
                  Our committed and diverse staff goes above and beyond their duties, reflected in the establishment of
                  community response structures such as the Woreda Advisory Committee (WAC/PAC). These structures
                  prioritize addressing the needs of vulnerable groups, ensuring program sustainability and community
                  engagement. HEAL's transparent partnerships and strong stakeholder engagement, combined with our
                  commitment to ethical work practices, have garnered trust and respect from both donors and
                  communities.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-blue-700 mb-12 text-center">Leadership</h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Dereje Deme, Executive Director"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-green-700 mb-4">Dereje Deme</h3>
                <p className="text-gray-600 mb-4">Executive Director</p>
                <p className="text-gray-700 mb-4">
                  Dereje Deme brings over two decades of experience in public and private institutions. He holds a BA in
                  Organizational Management and a Diploma in Agriculture and oversees daily operations, external
                  relations, and fundraising endeavors of HEAL. In addition, he serves on the boards of three local
                  NGOs.
                </p>
                <p className="text-gray-700">
                  Under his leadership, HEAL emphasizes teamwork, personal accountability, integrity, and
                  professionalism. HEAL strictly adheres to IPSAS using Peachtree Software, maintaining an internal
                  audit system and undergoing annual financial audits by independent firms. Reports are consistently
                  shared with donors and local stakeholders promptly, ensuring transparency throughout.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-yellow-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-blue-700 mb-6">Join Our Cause</h2>
            <p className="text-gray-700 max-w-3xl mx-auto mb-8">
              Together, we can break the cycle of poverty and create lasting change in the lives of vulnerable
              communities across Ethiopia. Join us in our mission to create sustainable impact.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/contact">
                <Button className="bg-green-600 hover:bg-green-700 text-white">Get Involved</Button>
              </Link>
              <Link href="/donate">
                <Button className="bg-red-600 hover:bg-red-700 text-white">Donate Now</Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}

