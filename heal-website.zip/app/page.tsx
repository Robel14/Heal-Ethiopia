import Link from "next/link"
import { Button } from "@/components/ui/button"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import MissionSection from "@/components/mission-section"
import ImpactHighlights from "@/components/impact-highlights"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <MissionSection />
      <ImpactHighlights />
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Support Our Cause</h2>
          <p className="max-w-2xl mx-auto mb-8">
            Your contribution helps us break the cycle of poverty and create sustainable change across Ethiopia.
          </p>
          <Link href="/donate">
            <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg">Donate Now</Button>
          </Link>
        </div>
      </section>
      <Footer />
    </main>
  )
}

