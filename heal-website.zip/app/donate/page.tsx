"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function DonatePage() {
  const [donationAmount, setDonationAmount] = useState<string>("")
  const [customAmount, setCustomAmount] = useState<string>("")
  const [paymentMethod, setPaymentMethod] = useState<string>("card")

  const handleDonationChange = (value: string) => {
    setDonationAmount(value)
    if (value !== "custom") {
      setCustomAmount("")
    }
  }

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCustomAmount(e.target.value)
    setDonationAmount("custom")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const amount = donationAmount === "custom" ? customAmount : donationAmount
    alert(`Thank you for your donation of $${amount}!`)
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <h1 className="text-3xl font-bold text-blue-700 mb-4">Support Our Cause</h1>
              <p className="text-gray-700">
                Your donation helps us continue our work in empowering communities and transforming lives across
                Ethiopia.
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-green-700">Make a Donation</CardTitle>
                <CardDescription>Choose an amount to donate or enter a custom amount.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit}>
                  <div className="space-y-6">
                    <div>
                      <Label className="text-base">Select Donation Amount</Label>
                      <RadioGroup
                        value={donationAmount}
                        onValueChange={handleDonationChange}
                        className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-3"
                      >
                        <div>
                          <RadioGroupItem value="10" id="amount-10" className="peer sr-only" />
                          <Label
                            htmlFor="amount-10"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-green-200 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
                          >
                            <span className="text-xl font-bold">$10</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="25" id="amount-25" className="peer sr-only" />
                          <Label
                            htmlFor="amount-25"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-green-200 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
                          >
                            <span className="text-xl font-bold">$25</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="50" id="amount-50" className="peer sr-only" />
                          <Label
                            htmlFor="amount-50"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-green-200 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
                          >
                            <span className="text-xl font-bold">$50</span>
                          </Label>
                        </div>
                        <div>
                          <RadioGroupItem value="100" id="amount-100" className="peer sr-only" />
                          <Label
                            htmlFor="amount-100"
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-white p-4 hover:bg-gray-50 hover:border-green-200 peer-data-[state=checked]:border-green-600 peer-data-[state=checked]:bg-green-50 [&:has([data-state=checked])]:border-green-600 cursor-pointer"
                          >
                            <span className="text-xl font-bold">$100</span>
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div>
                      <Label htmlFor="custom-amount">Custom Amount</Label>
                      <div className="relative mt-1">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">$</span>
                        <Input
                          id="custom-amount"
                          type="number"
                          min="1"
                          step="1"
                          placeholder="Enter amount"
                          className="pl-7"
                          value={customAmount}
                          onChange={handleCustomAmountChange}
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-base">Payment Method</Label>
                      <Tabs defaultValue="card" value={paymentMethod} onValueChange={setPaymentMethod} className="mt-3">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="card">Credit Card</TabsTrigger>
                          <TabsTrigger value="paypal">PayPal</TabsTrigger>
                          <TabsTrigger value="bank">Bank Transfer</TabsTrigger>
                        </TabsList>
                        <TabsContent value="card" className="mt-4 space-y-4">
                          <div className="grid gap-4">
                            <div>
                              <Label htmlFor="card-name">Name on Card</Label>
                              <Input id="card-name" placeholder="John Doe" />
                            </div>
                            <div>
                              <Label htmlFor="card-number">Card Number</Label>
                              <Input id="card-number" placeholder="1234 5678 9012 3456" />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="expiry">Expiry Date</Label>
                                <Input id="expiry" placeholder="MM/YY" />
                              </div>
                              <div>
                                <Label htmlFor="cvc">CVC</Label>
                                <Input id="cvc" placeholder="123" />
                              </div>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="paypal" className="mt-4">
                          <p className="text-gray-700 mb-4">
                            You will be redirected to PayPal to complete your donation.
                          </p>
                        </TabsContent>
                        <TabsContent value="bank" className="mt-4">
                          <div className="bg-gray-50 p-4 rounded-md">
                            <p className="font-medium mb-2">Bank Transfer Details:</p>
                            <p>Bank: Example Bank</p>
                            <p>Account Name: Hiwot Ethiopia</p>
                            <p>Account Number: 1234567890</p>
                            <p>SWIFT/BIC: EXAMPLEXXX</p>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </div>
                  </div>

                  <div className="mt-8">
                    <Button
                      type="submit"
                      className="w-full bg-red-600 hover:bg-red-700 text-white"
                      disabled={!donationAmount || (donationAmount === "custom" && !customAmount)}
                    >
                      Complete Donation
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <div className="mt-12 bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-bold text-blue-700 mb-4">Other Ways to Support</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-green-700 mb-2">Volunteer With Us</h3>
                  <p className="text-gray-700 mb-3">
                    Share your skills and time to help us make a difference in communities.
                  </p>
                  <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
                    Learn More
                  </Button>
                </div>
                <div>
                  <h3 className="font-semibold text-green-700 mb-2">Corporate Partnerships</h3>
                  <p className="text-gray-700 mb-3">
                    Partner with us to create sustainable impact and fulfill your CSR goals.
                  </p>
                  <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
                    Contact Us
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

